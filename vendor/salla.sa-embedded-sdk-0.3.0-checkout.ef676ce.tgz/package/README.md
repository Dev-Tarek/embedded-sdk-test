# @salla.sa/embedded-sdk

Communication bridge SDK for third-party apps embedded in the Salla Merchant Dashboard.

## Installation

```bash
npm install @salla.sa/embedded-sdk
# or
pnpm add @salla.sa/embedded-sdk
# or
yarn add @salla.sa/embedded-sdk
```

## Quick Start

```typescript
import { embedded } from "@salla.sa/embedded-sdk";

async function bootstrap() {
  try {
    // Initialize SDK
    const { layout } = await embedded.init({ debug: true });

    // Get token
    const token = embedded.auth.getToken();
    if (!token) throw new Error("No token found");

    // Verify token with your backend before signaling ready
    const isValid = await fetch("/api/verify-token", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token }),
    }).then((res) => res.ok);

    if (!isValid) throw new Error("Token is invalid");

    // Signal app is ready only after successful verification
    embedded.ready();

    // Set up your app
    embedded.page.setTitle("My App");
  } catch (err) {
    embedded.destroy();
  }
}

bootstrap();
```

### Browser Global

```html
<script src="https://unpkg.com/@salla.sa/embedded-sdk/dist/umd/index.js"></script>
<script>
  const embedded = Salla.embedded;
  embedded.init({ debug: true }).then((result) => {
    console.log("Layout:", result.layout);
    embedded.ready();
  });
</script>
```

## API Overview

The SDK provides modules for authentication, UI components, navigation, and page management:

- **Auth**: `getToken()`, `getAppId()`, `refresh()`, `introspect()`
- **UI**: `loading`, `breadcrumbs`, `toast`, `modal`, `confirm`
- **Page**: `setTitle()`, `navigate()`, `redirect()`
- **Nav**: `setAction()`, `onActionClick()`, `clearAction()`, `addNavItem()`, `updateNavItem()`, `removeNavItem()`, `onNavItemClick()`
- **Checkout**: `getAddons()`, `create()` (items or `{ checkout_id }` for a server-created checkout), `onResult()`

## TypeScript

Full TypeScript support with exported types. See [documentation](#) for complete type reference.

## Build Formats

| Format   | File                   |
| -------- | ---------------------- |
| ESM      | `dist/esm/index.js`    |
| CommonJS | `dist/cjs/index.js`    |
| UMD      | `dist/umd/index.js`    |
| SystemJS | `dist/system/index.js` |

## Documentation

For complete API documentation, examples, and advanced usage, see the [full documentation](#).
